<?php
echo '<hr>
<pre style="text-align:center;">
====================================================================
 This Program is Developed and Executed By 0231BCA222 - Akshay Jain
====================================================================
</pre>';
?>