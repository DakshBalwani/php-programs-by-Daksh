<?php
#arsort function
$age = array("Peter"=>"20", "Harry"=>"14", "John"=>"45", "Clark"=>"35");
arsort($age);
print_r($age);
?>
